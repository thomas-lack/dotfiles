tx_gridelements.setup {
	[elementName] {
		topLevelLayout = 0
		title = 
		description = 
		icon = 

		config {
			colCount = 
			rowCount = 
			rows {
				1 {
					columns {
						1 {
							name =
							colPos = 
							allowed =
							allowedGridTypes =
						}
					}
				}
			}
		}

		flexformDS (
		)
	}
}
